local postalfile = 'new-postals.json'
-- Resource Metadata
fx_version 'cerulean'
games { 'gta5' }

author 'Whitigol Web Design'
description 'Uses OCRP Postal Codes - Links to CosmicMDT'
version '1.0.0'
-- What to run
client_scripts {
    'client.lua',
}
file(postalfile)
postal_file(postalfile)


--[[
    Script created by Whitigol Web Design for Cosmic MDT
]]
