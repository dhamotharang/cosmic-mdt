-- Resource Metadata
fx_version 'cerulean'
games { 'gta5' }

author 'Dev-CasperTheGhost'
description 'Connect to your CosmicMDT'
version '1.0.0'

-- What to run
client_scripts {
    'client.lua',
}
server_script 'server.lua'

--[[
    Script created by Whitigol Web Design for Cosmic MDT
]]

